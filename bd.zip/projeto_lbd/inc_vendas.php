<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }

    //$id_produto = $_POST['id_produto'];
    $id_cliente = $_POST['id_cliente'];
    $id_vendedor = $_POST['id_vendedor'];
    $data = $_POST['data'];
    $prazo = $_POST['entrega'];
    $cond_pagto = $_POST['cond_pagto'];

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    include('conexao.php');
    mysqli_begin_transaction($con) or die (mysqli_connect_error());
    try
    {
        $query = "INSERT INTO venda (fk_cod_cliente,fk_cod_vendedor,cond_pagamento,prazo_entrega,data) 
        VALUES ('$id_cliente', '$id_vendedor', '$cond_pagto', '$prazo', '$data')";
        $resu = mysqli_query($con,$query);
    
        mysqli_commit($con);
        $_SESSION['msg'] = "<p style = 'color:green;'>  Venda cadastrada </p>";
        header("Location: vendas.php");
    }
    catch (mysqli_sql_exception $exception)
    {
        mysqli_rollback($con);

        throw $exception;
        $_SESSION['msg'] = "<p style = 'color:red;'>  Venda não cadastrada </p>";
        header("Location: vendas.php");
    }
    mysqli_close($con);
?> 