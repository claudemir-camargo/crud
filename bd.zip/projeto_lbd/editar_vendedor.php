<?php
    session_start();
    include("conexao.php");
    $codigo = $_POST['codigo'];
    $nome = $_POST['nome'];
    $cidade = $_POST['cidade'];
    $rua = $_POST['rua'];
    $num = $_POST['num'];
    $bairro = $_POST['bairro'];
    $estado = $_POST['estado'];
    $tel = $_POST['tel'];
    $comissao = $_POST['comissao'];

    $query = "UPDATE vendedor SET nome = '$nome', cidade = '$cidade', rua = '$rua', numero = '$num', bairro = '$bairro', estado = '$estado', telefone = '$tel', porc_comissao = '$comissao' WHERE codigo = '$codigo'"; 
    $resultado = mysqli_query($con, $query) or die (mysqli_connect_error());

    if(mysqli_affected_rows($con))
        {
            $_SESSION['msg'] = "<p style = 'color:green;'> Alteração concluida </p>";
            header("Location: busca_v.php");
        }
        else
        {
            $_SESSION['msg'] = "<p style = 'color:green;'>  Falha na alteração </p>";
            header("Location: busca_v.php");
        }
        mysqli_close($con);
?>