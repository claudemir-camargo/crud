<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <hr>
    </head>

    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
            <title>Vendas/Produtos</title>
            <h1>Vendas</h1>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 20px;
		    font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
                <tr>
                    <th>Número</th>
                    <th>Data</th>
                    <th>Prazo de Entrega</th>
                    <th>Condição Pagamento</th>
                    <th>Código Cliente</th>
                    <th>Código Vendedor</th>
                    
                </tr>
            </thead>
       
                <?php include_once'conexao.php'; ?>

                <?php
                    $resul_nomes = "SELECT * FROM venda ORDER BY numero";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha['numero'] . "</td>";
                        echo "<td>" . $linha['data'] . "</td>";
                        echo "<td>" . $linha['prazo_entrega'] . "</td>";
                        echo "<td>" .$linha['cond_pagamento'] . "</td>";
                        echo "<td>" . $linha['fk_cod_cliente'] . "</td>";
                        echo "<td>" .$linha['fk_cod_vendedor'] . "</td><tr>";
                    
                    }
                ?>
            </table>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 20px;
		    font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
                <tr>
                    <th>Código</th>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Qtd. Estoque</th>
                    <th>Unidade Medida</th>
                    <th>Categoria</th>
                </tr>
            </thead>
                <h1>Produtos</h1>
                <br>
                <?php
                    $resul_nomes = "SELECT * FROM produto ORDER BY nome";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha_c = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha_c['codigo'] . "</td>";
                        echo "<td>" . $linha_c['nome'] . "</td>";
                        echo "<td>" . $linha_c['preco'] . "</td>";
                        echo "<td>" .$linha_c['qtd_estoque'] . "</td>";
                        echo "<td>" . $linha_c['unid_medida'] . "</td>";
                        echo "<td>" .$linha_c['fk_id_categoria'] . "</td></td>";  
                    }
                ?>
            </table>
        </form>
        <p><a href="itens_vendas.php"><button>Voltar</button></a><br>
        <?php mysqli_close($con); ?>
    </body>
</html>