<?php
    include_once("conexao.php");
    $sql = " SELECT descricao, id FROM categoria;";
    $resultado = mysqli_query($con,$sql) or die("Erro ao retornar dados");
    
    $html="";

    $html .= "<style> hr { background-color: aqua; border: none; }</style>";

    $html .= "<h1 size='20'><p align='center'> <b font-family: arial, sans-serif;>Relatório de Produtos</b></h1><hr>";
    while ($registro = mysqli_fetch_array($resultado)){
        $categoria = $registro['descricao'];
        $id = $registro['id'];
        $html .= "<hr size='5'>";
        $html .= "<center><b>Categoria: ".$categoria."</b></center><br>";
        $html .= "<table border='1' width='95%' style='background-color: aqua; text-align: center; font-size: 15px;
        font-family: arial, sans-serif;'>";
        $html .= "<tr><td align='center'><b>Produto:</b> </td><td align='center'><b>Preço:</b>
        </td><td align='center'><b>Quantidade no estoque:</b></td><td align='center'><b>Unidade de medida:</b></td>";

$query = "SELECT nome, preco, qtd_estoque, unid_medida FROM produto p INNER JOIN categoria c 
ON p.fk_id_categoria = c.id WHERE p.fk_id_categoria = '$id'";
$resultado2 = mysqli_query($con, $query) or die("Erro ao retornar dados!");

while($registro2 = mysqli_fetch_array($resultado2))
{
    $html.="<tr><td>".$registro2['nome']."</td>
    <td align='center'>"."R$ ".$registro2['preco']."</td>
    <td align='center'>".$registro2['qtd_estoque']."</td>
    <td align='center'>".$registro2['unid_medida']."</td>";
}
$html .= "</table><br>";
}
mysqli_close($con);
use Dompdf\Dompdf;

require_once("C:/xampp/htdocs/projeto_lbd/dompdf/dompdf/autoload.inc.php");

$dompdf = new DOMPDF();

$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream(
    "relatorio_pdf.pdf",
    array(
        "Attachment" => false
    )
    );
?>
