<!DOCTYPE html>
<html>
    <head>
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="UTF-8">
        <title>Produtos</title>
        <hr>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php 
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
        <p><center><h1>Produtos</center></h1>
        <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 20px;
		font-family: arial, sans-serif;">
        <thead style="background-color: blue;">
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>Preço</th>
                <th>Qtd. Estoque</th>
                <th>Unidade de Medida</th>
                <th>ID Categoria</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <?php
            include_once('conexao.php');
            $query = "SELECT * FROM produto ORDER BY nome";
            $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
            while($reg = mysqli_fetch_array($resu))
            {
                echo "<tr><td>".$reg['codigo']."</td>";
                echo "<td>".$reg['nome']."</td>";
                echo "<td>".$reg['preco']."</td>";
                echo "<td>".$reg['qtd_estoque']."</td>";
                echo "<td>".$reg['unid_medida']."</td>";
                echo "<td>".$reg['fk_id_categoria']."</td>";
                echo "<td><a href='edit_produto.php?codigo=".$reg['codigo']."'><img src='editar.png'/></a></td>";
                echo "<td><a href='del_produto.php?codigo=".$reg['codigo']."'><img src='deletar.png'/></a></td>";
            }
        ?>
        </table></form>
        <p><a href="salvar_produto.php"><button>Voltar</button></a>
        <?php
        mysqli_close($con)?>
    </body>
</html>
        