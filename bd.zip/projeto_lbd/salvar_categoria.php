<!DOCTYPE html>
<html>
<head>
<a href="home.html"><img src="lcm.jpg" width="100"></a>
    <meta charset="UTF-8">
    <title>Inclusão - Categoria</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
    <h1>Cadastro de Categoria</h1>
    <hr>
    <form method="post" action="">
    <label><p>Descrição: <input type="text" name="descricao" size="50" maxlength="50"></p></label>
    <p><button type="submit" value="cadastrar">Cadastrar</button>
    <button type="reset" value="Limpar">Limpar</button>   
    </form> 
    <div>
        <p><a href="home.html"><button>Voltar</button></a>
        <a href="alter_categoria.php"><button>Lista de Categorias</button></a>
    </div>
    </div>
</body>
</html>

<?php
if(!empty($_POST)){
    $descricao = $_POST['descricao'];
include('conexao.php');

$query = "INSERT INTO categoria(descricao) VALUES ('$descricao')";
$resu = mysqli_query($con, $query);
if (mysqli_insert_id($con))
{
    echo "<br>Inclusão realizada com sucesso!";
}
mysqli_close($con);
}

