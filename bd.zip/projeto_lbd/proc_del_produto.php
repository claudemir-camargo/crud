<?php
session_start();
include('conexao.php');

$codigo = $_POST['codigo'];
$result = "DELETE FROM produto WHERE codigo='$codigo'";
$resultado = mysqli_query($con, $result) or die(mysqli_connect_error());

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Produto excluído com sucesso</p>";
    header("Location: alter_produto.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Produto não foi excluído, verifique novamente</p>";
    header("Location: alter_produto.php");
}
mysqli_close($con);
?>