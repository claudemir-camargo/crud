<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
            <title>Vendedores/Clientes</title>
            <h1>Vendedores</h1>
            <br>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>Rua</th>
                <th>Número</th>
                <th>Bairro</th>
                <th>Cidade</th>
                <th>Estado</th>
                <th>Telefone</th>
                <th>% Comissão</th>
            </tr>
        </thead>
                <?php include_once'conexao.php'; ?>

                <?php
                    $resul_nomes = "SELECT * FROM vendedor ORDER BY nome";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha['codigo'] . "</td>";
                        echo "<td>" . $linha['nome'] . "</td>";
                        echo "<td>" .$linha['rua'] . "</td>";
                        echo "<td>" . $linha['numero'] . "</td>";
                        echo "<td>" .$linha['bairro'] . "</td>";
                        echo "<td>" . $linha['cidade'] . "</td>";
                        echo "<td>" .$linha['estado'] . "</td>";
                        echo "<td>" . $linha['telefone'] . "</td>";
                        echo "<td>" . $linha['porc_comissao'] . "</td>";
                    }
                ?>
            </table>
            <hr>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		    font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>CPF</th>
                <th>E-mail</th>
                <th>Rua</th>
                <th>Número</th>
                <th>Bairro</th>
                <th>Cidade</th>
                <th>Estado</th>
                <th>Telefone</th>
                <th>Limite de Crédito</th>
            </tr>
        </thead>
                <h1>Clientes</h1>
                <br>
                <?php
                    $resul_nomes = "SELECT * FROM cliente ORDER BY nome";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha_c = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha_c['codigo'] . "</td>";
                        echo "<td>" . $linha_c['nome'] . "</td>";
                        echo "<td>" . $linha_c['cpf'] . "</td>";
                        echo "<td>" .$linha_c['email'] . "</td>";
                        echo "<td>" . $linha_c['rua'] . "</td>";
                        echo "<td>" .$linha_c['numero'] . "</td>";
                        echo "<td>" .$linha_c['bairro'] . "</td>";
                        echo "<td>" . $linha_c['cidade'] . "</td>";
                        echo "<td>" . $linha_c['estado'] . "</td>";
                        echo "<td>" . $linha_c['telefone'] . "</td>";
                        echo "<td>" . $linha_c['limite_cred'] . "</td>";
                    }
                ?>
            </table>
        </form>
        <div>
            <p ><a href="vendas.php" ><button style="text-align: center;">Voltar</button></a>
        </div>
        <?php mysqli_close($con); ?>
    </body>
</html>