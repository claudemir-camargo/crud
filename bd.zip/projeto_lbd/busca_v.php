<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
            <title>Vendedor</title>
            <h1 style="text-align: center;">Lista de vendedores</h1>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>Rua</th>
                <th>Número</th>
                <th>Bairro</th>
                <th>Cidade</th>
                <th>Estado</th>
                <th>Telefone</th>
                <th>% Comissão</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
                <?php include_once'conexao.php'; ?>

                <?php
                    //$busca = $_POST['busca'];
                    $resul_nomes = "SELECT * FROM vendedor ORDER BY nome";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha['codigo'] . "</td>";
                        echo "<td>" . $linha['nome'] . "</td>";
                        echo "<td>" .$linha['rua'] . "</td>";
                        echo "<td>" . $linha['numero'] . "</td>";
                        echo "<td>" .$linha['bairro'] . "</td>";
                        echo "<td>" . $linha['cidade'] . "</td>";
                        echo "<td>" .$linha['estado'] . "</td>";
                        echo "<td>" . $linha['telefone'] . "</td>";
                        echo "<td>" . $linha['porc_comissao'] . "</td>";
                        echo "<td><a href='edit_vendedor.php?codigo=".$linha['codigo']."'><img src='editar.png'/></a></td>";
                        echo "<td><a href='del_vendedor.php?codigo=".$linha['codigo']."'><img src='deletar.png'/></a></td>";
                    }
                ?>
            </table>
        </form>
        <div>
            <p ><a href="vendedor.php" ><button style="text-align: center;">Voltar</button></a>
        </div>
        
        <?php mysqli_close($con); ?>
    </body>
</html>