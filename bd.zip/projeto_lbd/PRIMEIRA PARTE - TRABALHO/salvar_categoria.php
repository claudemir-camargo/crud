<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Inclusão - Categoria</title>
    <link rel="stylesheet" type="text/css" href="style1.css" />
</head>
<body>
    <p><h1>Inclusão - Categoria</h1></p>
    <form method="post" action="">
    <p>Descrição: <input type="text" name="descricao" size="50" maxlength="50" required>
    <p><button type="submit" value="cadastrar">Cadastrar</button>
            <p><button type="reset" value="Limpar">Limpar</button>
            
    </form>
    <p><a href="home.html"><button>Voltar</button></a>
</body>
</html>

<?php
if(!empty($_POST)){
    $descricao = $_POST['descricao'];
include('conexao.php');

$query = "INSERT INTO categoria(descricao) VALUES ('$descricao')";
$resu = mysqli_query($con, $query);
if (mysqli_insert_id($con))
{
    echo "<br>Inclusão realizada com sucesso!";
}
mysqli_close($con);
}

