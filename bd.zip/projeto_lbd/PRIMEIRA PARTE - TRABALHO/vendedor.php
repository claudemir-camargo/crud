<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<?php
    include("conexao.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style1.css" />
    </head>
    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <div class="box">
            <form method="POST" action="busca_v.php">
                <input type="submit" value="Tabela de vendedores">
            </form>
            <form method="POST" action="inc_vendedor.php">
                <div class="form">
                <center>
                    <h2>Vendedor</h2>
                    <div class="inputbox">
                        
                        <table>
                            <tr>
                                <td>Nome: </td><td><input type="text" name="nome" required></td>
                            </tr>
                            <tr>
                                <td>Cidade: </td><td ><input type="text" name="cidade" required></td>
                            </tr>
                            <tr>
                                <td>Rua: </td><td><input type="text" name="rua" required></td><td>Nº:</td><td><input type="number" name="num"></td>
                            </tr>
                            <tr>
                                <td>Bairro: </td><td><input type="text" name="bairro" required></td>
                            </tr>
                            <tr>
                                <td>Estado: </td>
                                <td>
                                    <select name="estado" required>
                                        <option value="SP">SP</option>
                                        <option value="BA">BA</option>
                                        <option value="RJ">RJ</option>
                                        <option value="MG">MG</option>
                                        <option value="PR">PR</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Telefone: </td><td><input type="tel" name="tel" placeholder="(xx) xxxxx-xxxx" required></td>
                            </tr>
                            <tr>
                                <td>Comissão: </td><td><input type="number" name="comissao" required></td>
                            </tr>
                        </table>
                    </div>
                    <p><button type="submit" value="cadastrar">Cadastrar</button>
                    <p><button type="reset" value="Limpar">Limpar</button>
                </center>
                </div>
            </form>
            <p><a href="home.html"><button>Voltar</button></a>
        </div>
    </body>
</html>