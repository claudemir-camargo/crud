<?php
session_start();
include_once('conexao.php');

$id = $_POST['id'];
$nome = $_POST['nome'];
$verif = "SELECT*FROM produto WHERE fk_id_categoria='$id'";
$resu = mysqli_query($con, $verif);

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Esta categoria não pode ser excluída, pois existe produto 
    cadastrado</p>";
    header("Location: alter_categoria.php");
}

else{
    $result = "DELETE FROM categoria WHERE id='$id'";
    $resultado = mysqli_query($con, $result) or die(mysqli_connect_error());

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Categoria excluída com sucesso</p>";
    header("Location: alter_categoria.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Categoria não foi excluída, verifique novamente</p>";
    header("Location: alter_categoria.php");
}
mysqli_close($con);
}
?>
