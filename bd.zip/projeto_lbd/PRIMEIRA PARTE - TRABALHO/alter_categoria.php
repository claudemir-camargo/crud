<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Categoria</title>
    </head>
    <body>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
        <p><center><h1>Categoria</center></h1>
        <table border="1" width="100%">
        <?php
            require 'conexao.php';
            $query = "SELECT * FROM categoria";
            $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
            while($reg = mysqli_fetch_array($resu))
            {
                echo "<tr><td>".$reg['descricao']."</td>";
                echo "<td><a href='edit_categoria.php?id=".$reg['id']."'>Editar</a></td>";
                echo "<td><a href='del_categoria.php?id=".$reg['id']."'>Excluir</a></td>";
            }
        ?>
        </table></form>
        <?php
        mysqli_close($con)?>
    </body>
</html>
        