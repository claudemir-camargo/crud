<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>

    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
            <title><center>Vendedor</center></title>
            <h1 style="text-align: center;">Lista de vendedores</h1>
            <table width="100%" border="1px">
                <?php include_once'conexao.php'; ?>

                <?php
                    //$busca = $_POST['busca'];
                    $resul_nomes = "SELECT * FROM vendedor ORDER BY nome";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha['codigo'] . "</td>";
                        echo "<td>" . $linha['nome'] . "</td>";
                        echo "<td>" . $linha['cidade'] . "</td>";
                        echo "<td>" .$linha['rua'] . "</td>";
                        echo "<td>" . $linha['numero'] . "</td>";
                        echo "<td>" .$linha['bairro'] . "</td>";
                        echo "<td>" .$linha['estado'] . "</td>";
                        echo "<td>" . $linha['telefone'] . "</td>";
                        echo "<td>" . $linha['porc_comissao'] . "</td>";
                        echo "<td><a href='edit_vendedor.php?codigo=".$linha['codigo']."'>Editar</a></td>";
                        echo "<td><a href='del_vendedor.php?codigo=".$linha['codigo']."'>Excluir</a></td>";
                    }
                ?>
            </table>
        </form>
        <p><a href="vendedor.php"><button>Voltar</button></a>
        <?php mysqli_close($con); ?>
    </body>
</html>