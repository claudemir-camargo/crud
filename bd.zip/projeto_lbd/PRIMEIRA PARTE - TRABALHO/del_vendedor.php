<?php

    session_start();
    include_once("conexao.php");
    $codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
    $result = "SELECT * FROM vendedor WHERE codigo = '$codigo'";
    $resultado = mysqli_query($con, $result);
    $row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <h1>Excluir</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="deletar_vendedor.php">
            <input type="hidden" name="codigo" value="<?php echo $row['codigo'];?>">
            <table>
                <tr>
                    <td>Nome: </td><td><input type="text" name="nome" value="<?php echo $row['nome'];?>" disabled></td>
                </tr>
                <tr>
                    <td>Cidade: </td><td ><input type="text" name="cidade" value="<?php echo $row['cidade'];?>" disabled></td>
                </tr>
                <tr>
                    <td>Rua: </td><td><input type="text" name="rua" value="<?php echo $row['rua'];?>"></td><td>Nº:</td><td><input type="number" name="num" value="<?php echo $row['numero'];?>" disabled></td>
                </tr>
                <tr>
                    <td>Bairro: </td><td><input type="text" name="bairro" value="<?php echo $row['bairro'];?>" disabled></td>
                </tr>
                <tr>
                    <td>Estado: </td><td><input type="text" name="estado" value="<?php echo $row['estado'];?>" disabled></td>
                    <td>
                        <select name="estado" disabled>
                            <option value="SP">SP</option>
                            <option value="BA">BA</option>
                            <option value="RJ">RJ</option>
                            <option value="MG">MG</option>
                            <option value="PR">PR</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Telefone: </td><td><input type="tel" name="tel" placeholder="(xx) xxxxx-xxxx" value="<?php echo $row['telefone'];?>" disabled></td>
                </tr>
                <tr>
                    <td>Comissão: </td><td><input type="number" name="comissao" value="<?php echo $row['porc_comissao'];?>" disabled></td>
                </tr>
            </table>
            <input type="submit" value="Confirmar exclusão">
        </form>
        <?php mysqli_close($con) ?>
    </body>
</html>