<?php
$con = mysqli_connect('localhost', 'root', '', 'projeto');
if (!$con)
{
    echo "Erro na conexão com MySQL<br>";
    echo "Erro".mysqli_connect();
    exit;
}
?>