<?php
session_start();
include('conexao.php');

$codigo = $_POST['codigo'];
$result = "DELETE FROM cliente WHERE codigo='$codigo'";
$resultado = mysqli_query($con, $result) or die(mysqli_connect_error());

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Cliente excluído com sucesso</p>";
    header("Location: alter_cliente.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Cliente não foi excluído, verifique novamente</p>";
    header("Location: alter_cliente.php");
}
mysqli_close($con);
?>