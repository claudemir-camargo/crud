<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <a href="home.html"><img src="lcm.jpg" width="100"></a>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa de Clientes</title>
    <hr>
    <style>
        body{
            width: 100vw;
            height: 100vh;
            /*display: flex;*/
            justify-content: center;
            align-items: center;
            background-color: #e7eed0;
        }
    </style>
</head>
<body>
    <h3>Filtrar por: </h3><br>
    <form action="" method="POST">
        <label>Nome do cliente: </label><input type="text" name="nome" size="50"/>
        <label>Código: </label><input type="number" name="codigo"/>
        <p><input type="submit" name="SendPesqUser" value="Pesquisar">
    </form>
    <a href="cad_cliente.php"><button>Voltar</button></a>
    <hr size="15">

    <?php
    include("conexao.php");
    $SendPesqUser = filter_input(INPUT_POST, 'SendPesqUser', FILTER_SANITIZE_SPECIAL_CHARS);
    if($SendPesqUser)
    {
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $codigo = filter_input(INPUT_POST, 'codigo', FILTER_SANITIZE_NUMBER_INT);

        if(empty($nome) && empty($codigo))
        {
            $query = "SELECT*FROM consulta_cliente";
        }
        elseif(empty($nome) && !empty($codigo))
        {
            $query = "SELECT*FROM consulta_cliente WHERE codigo = '$codigo'";
        }
        elseif(!empty($nome) && empty($codigo))
        {
            $query = "SELECT*FROM consulta_cliente WHERE nome LIKE '%$nome%'";
        }
        else
        {
            $query = "SELECT*FROM consulta_cliente WHERE nome LIKE '%$nome%' OR codigo = '$codigo'";
        }

        $resultado = mysqli_query($con, $query) or die("Erro ao retornar dados!");
        while($row = mysqli_fetch_assoc($resultado))
        {
            echo "Código: ".$row['codigo']."<br>";
            echo "Cliente: ".$row['nome']."<br>";
            echo "CPF: ".$row['cpf']."<br>";
            echo "E-mail: ".$row['email']."<br>";
            echo "Rua: ".$row['rua']."<br>";
            echo "Número: ".$row['numero']."<br>";
            echo "Bairro: ".$row['bairro']."<br>";
            echo "Cidade: ".$row['cidade']."<br>";
            echo "Estado: ".$row['estado']."<br>";
            echo "Telefone: ".$row['telefone']."<br>";
            echo "Limite de crédito: ".$row['limite_cred']."<br><hr>";
        }
    }
    ?>
</body>
</html>