<?php
session_start();
include_once('conexao.php');
$codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
$result = "SELECT * FROM produto WHERE codigo = '$codigo'";
$resultado = mysqli_query($con, $result);
$row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - Excluir</title>
    <link rel="stylesheet" href="style.css">
    <a href="home.html"><img src="lcm.jpg" width="100"></a>
</head>
<body>
    <h1>Exclusão - Produto</h1>
    <?php
    if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
        }
    ?>
    <form method="POST" action="proc_del_produto.php">
        <input type="hidden" name="codigo" value="<?php echo $row['codigo']; ?>">
        <label>Nome do produto: </label>
        <p><input type="text" name="nome" value="<?php echo $row['nome']; ?>" disabled><br><br>
        <button type="submit" value="excluir">Excluir</button>
    </form>  
    <p><a href="alter_produto.php"><button>Voltar</button></a> 
</body>
</html>