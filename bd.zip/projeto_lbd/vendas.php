<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Vendas</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
    </head>
    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <div class="box">
            <form method="POST" action="inc_vendas.php">
                <div class="form">
                    <h2>Vendas</h2>
                    <div class="inputbox">
                        <label><p>Código Cliente: <input type="number" name="id_cliente"></label>
                        <label><p>Código Vendedor: <input type="number" name="id_vendedor" ></label>
                        <label><p>Data: <input type="date" name="data" ></label>
                        <label><p>Prazo de Entrega: <input type="text" name="entrega" ></label>
                        <label><p>Condição Pagamento: <input type="text" name="cond_pagto" ></label>
                    </div>
                    <p><button type="submit" value="cadastrar">Cadastrar</button>
                    <button type="reset" value="Limpar">Limpar</button>
                </div>
            </form>
            <div>
                <a href="tabela_vendas.php"><button>Tabela de Vendas</button></a>
                <a href="busca_vendas.php"><button>Clientes/Vendedores</button></a>
                <p><a href="home.html"><button>Voltar</button></a><br>
            </div>
        </div>
    </body>
</html>