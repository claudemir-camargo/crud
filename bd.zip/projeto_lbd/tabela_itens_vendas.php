<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <hr>
    </head>

    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
            <title>Itens/Vendas</title>
            <h1>Itens/Vendas</h1>
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		    font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
            <tr>
                <th>Código do Produto</th>
                <th>ID Venda</th>
                <th>Quantidade</th>
                <th>Excluir</th>
            </tr>
        </thead>
                <?php include_once'conexao.php'; ?>

                <?php
                    $resul_nomes = "SELECT * FROM item_vendas ORDER BY fk_cod_produto";
                    $resul_busca = mysqli_query($con, $resul_nomes) or die (mysqli_connect_error());

                    while($linha = mysqli_fetch_array($resul_busca))
                    {
                        echo "<tr><td>" .$linha['fk_cod_produto'] . "</td>";
                        echo "<td>" . $linha['fk_num_venda'] . "</td>";
                        echo "<td>" . $linha['quantidade'] . "</td>";
                        echo "<td><a href='del_itens_vendas.php?fk_num_venda=".$linha['fk_num_venda']."'><img src='deletar.png'/></a></td></tr>";
                    
                    }
                ?>
            </table>
        </form>
        <p><a href="itens_vendas.php"><button>Voltar</button></a>
        <?php mysqli_close($con); ?>
    </body>
</html>