<?php
if (session_status() !== PHP_SESSION_ACTIVE)
{
    session_start();
}
$nome = $_POST['nome'];
$preco = $_POST['preco'];
$qtd_estoque = $_POST['qtd_estoque'];
$unid_medida = $_POST['unid_medida'];
$fk_id_categoria = $_POST['fk_id_categoria'];

include('conexao.php');

$query = "INSERT INTO produto(nome, preco, qtd_estoque, unid_medida, fk_id_categoria)
 VALUES ('$nome', '$preco', '$qtd_estoque', '$unid_medida', '$fk_id_categoria')";
$resu = mysqli_query($con, $query);

if (mysqli_insert_id($con))
{
    $_SESSION['msg'] = "<p style = 'color:blue;'> Produto cadastrado com sucesso!</p>";
    header('Location: salvar_produto.php');
}
else
{
    $_SESSION['msg'] = "<p style = 'color:red;'> Produto não cadastrado!</p>";
    header('Location: salvar_produto.php');
}
mysqli_close($con);
?>