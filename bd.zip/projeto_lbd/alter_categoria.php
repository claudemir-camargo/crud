<!DOCTYPE html>
<html>
    <head>
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="UTF-8">
        <title>Categoria</title>
        <link rel="stylesheet" href="style.css">
        <hr>
    </head>
    
    <body>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
        <p><center><h1>Categoria</center></h1>
        <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 20px;
		font-family: arial, sans-serif;">
        <thead style="background-color: blue;">
            <tr>
                <th>ID</th>
                <th>Descrição</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <?php
            include_once('conexao.php');
            $query = "SELECT * FROM categoria ORDER BY descricao";
            $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
            while($reg = mysqli_fetch_array($resu))
            {
                echo "<tr><td>".$reg['id']."</td>";
                echo "<td>".$reg['descricao']."</td>";
                echo "<td><a href='edit_categoria.php?id=".$reg['id']."'><img src='editar.png'/></a></td>";
                echo "<td><a href='del_categoria.php?id=".$reg['id']."'><img src='deletar.png'/></a></td>";
            }
        ?>
        </table>
    </form>
    <p><a href="salvar_categoria.php"><button>Voltar</button></a>
        
        <?php
        mysqli_close($con)?>
    </body>
</html>
        