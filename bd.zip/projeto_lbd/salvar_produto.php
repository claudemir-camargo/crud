<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html>
    <head>
    <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="UTF-8">
        <title>Cadastro de produtos</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <?php
            require 'conexao.php';
            $query = "SELECT * FROM categoria";
            $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
        ?>
        <br>
        <div>
        <p><h1>Cadastro de produtos</h1></p>
        <hr>
        <form method="POST" action="inc_produto.php">
        <label><p>Nome do produto: <input type="text" size="50" name="nome" maxlength="100"></p></label>
        <label><p>Preço: <input type="number" min="0" step=".01" size="10" name="preco" maxlength="10"></p></label>
        <label><p>Quantidade em estoque: <input type="number" size="80" name="qtd_estoque" maxlength="10"></p></label>
        <label><p>Unidade de medida: <input type="text" name="unid_medida" maxlength="20"></label>
        <label><p>Categoria: </label><select name="fk_id_categoria">
            <option value="Selecione" selected>Selecione</option>
            <option value="Selecione"></option>
            <?php
            while ($reg = mysqli_fetch_assoc($resu))
            {
                ?>
                <option value="<?php echo $reg['id']?>">
                    <?php echo $reg['descricao']?>
                </option>
            <?php
            }
            mysqli_close($con);
            ?>
            </select>
            
            <p><button type="submit" value="cadastrar">Cadastrar</button>
            <button type="reset" value="Limpar">Limpar</button>
        </form>
        </div>
        <div>
            <a href="alter_produto.php"><button>Tabela de Produtos</button></a>
            <a href="consulta_produto.php"><button>Consulta de Produtos</button></a>
            <p><a href="home.html"><button>Voltar</button></a><br>
        </div>
        
    </body>
</html>