<?php

    session_start();
    include_once("conexao.php");
    $codigo = filter_input(INPUT_GET, 'fk_num_venda', FILTER_SANITIZE_NUMBER_INT);
    $result = "SELECT * FROM item_vendas WHERE fk_num_venda = '$codigo'";
    $resultado = mysqli_query($con, $result);
    $row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="utf-8">
        <title></title>
        <hr>
    </head>
    <body>
        <h1>Excluir</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="deletar_itens_vendas.php">
            <input type="number" name="fk_num_venda" value="<?php echo $row['fk_num_venda'];?>">
            <table>
                <tr>
                    <td>Código Produto: </td><td><input type="number" name="id_produto" value="<?php echo $row['fk_cod_produto'];?>" disabled></td>
                    <td>ID Venda: </td><td><input type="number" name="id_vendas" value="<?php echo $row['fk_num_venda'];?>" disabled></td>
                    <td>Quantidade: </td><td><input type="number" name="quant" value="<?php echo $row['quantidade'];?>" disabled></td>
                </tr>  
            </table>
            <button type="submit" value="excluir">Excluir</button>
        </form>
        <p><a href="tabela_itens_vendas.php"><button>Voltar</button></a>
        <?php mysqli_close($con) ?>
    </body>
</html>