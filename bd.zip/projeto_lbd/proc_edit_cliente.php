<?php
session_start();
include('conexao.php');

$codigo = $_POST['codigo'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$telefone = $_POST['telefone'];
$limite_cred = $_POST['limite_cred'];
$result = "UPDATE cliente SET nome='$nome', cpf='$cpf', email='$email', rua='$rua', numero='$numero', bairro='$bairro',
 cidade='$cidade', estado='$estado', telefone='$telefone', limite_cred='$limite_cred' WHERE codigo='$codigo'";
$resultado = mysqli_query($con, $result) or die(mysqli_connect_error());

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Cliente alterado com sucesso</p>";
    header("Location: alter_cliente.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Cliente não foi alterado, verifique novamente</p>";
    header("Location: alter_cliente.php");
}
mysqli_close($con);
?>