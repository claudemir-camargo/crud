<!DOCTYPE html>
<html>
    <head>
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="UTF-8">
        <title>Clientes</title>
        <hr>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="">
        <p><center><h1>Clientes</center></h1>
        <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		font-family: arial, sans-serif;">
        <thead style="background-color: blue;">
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>CPF</th>
                <th>E-mail</th>
                <th>Rua</th>
                <th>Número</th>
                <th>Bairro</th>
                <th>Cidade</th>
                <th>Estado</th>
                <th>Telefone</th>
                <th>Limite de Crédito</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <?php
            include_once('conexao.php');
            $query = "SELECT * FROM cliente ORDER BY nome";
            $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
            while($reg = mysqli_fetch_array($resu))
            {
                echo "<tr><td>".$reg['codigo']."</td>";
                echo "<td>".$reg['nome']."</td>";
                echo "<td>".$reg['cpf']."</td>";
                echo "<td>".$reg['email']."</td>";
                echo "<td>".$reg['rua']."</td>";
                echo "<td>".$reg['numero']."</td>";
                echo "<td>".$reg['bairro']."</td>";
                echo "<td>".$reg['cidade']."</td>";
                echo "<td>".$reg['estado']."</td>";
                echo "<td>".$reg['telefone']."</td>";
                echo "<td>".$reg['limite_cred']."</td>";
                echo "<td><a href='edit_cliente.php?codigo=".$reg['codigo']."'><img src='editar.png'/></a></td>";
                echo "<td><a href='del_cliente.php?codigo=".$reg['codigo']."'><img src='deletar.png'/></a></td>";
            }
        ?>
        </table></form>
        <p><a href="cad_cliente.php"><button>Voltar</button></a>
        <?php
        mysqli_close($con)?>
    </body>
</html>
        