<?php 
    session_start();
    $codigo = $_POST['fk_num_venda'];
    // $cod_produto = $_POST['fk_cod_produto'];

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    include("conexao.php");
    mysqli_begin_transaction($con) or die (mysqli_connect_error());
    try
    {
        
        $query_item_venda = "DELETE FROM item_vendas WHERE fk_num_venda='$codigo'";
        $result = mysqli_query($con, $query_item_venda);

       $query_venda = "DELETE FROM venda WHERE numero = '$codigo'";
       $result3 = mysqli_query($con, $query_venda);
        
        mysqli_commit($con);
        $_SESSION['msg'] = "<p style = 'color:green;'> Exclusão concluida </p>";
        header("Location: tabela_itens_vendas.php");
    }
    catch (mysqli_sql_exception $exception)
    {
        mysqli_rollback($con);
        throw $exception;
        $_SESSION['msg'] = "<p style = 'color:green;'> Falha na exclusão </p>";
        header("Location: tabela_itens_vendas.php");
    }
    mysqli_close($con);
?>