<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }

    $nome = $_POST['nome'];
    $cidade = $_POST['cidade'];
    $rua = $_POST['rua'];
    $num = $_POST['num'];
    $bairro = $_POST['bairro'];
    $estado = $_POST['estado'];
    $tel = $_POST['tel'];
    $comissao = $_POST['comissao'];

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    include('conexao.php');
    mysqli_begin_transaction($con) or die (mysqli_connect_error());
    try
    {
        $query = "INSERT INTO vendedor (nome,cidade,rua,numero,bairro,estado,telefone,porc_comissao) VALUES ('$nome', '$cidade', '$rua', '$num', '$bairro', '$estado', '$tel', '$comissao')";
        $resu = mysqli_query($con,$query);
    
        mysqli_commit($con);
        $_SESSION['msg'] = "<p style = 'color:green;'>  Vendedor cadastrado </p>";
        header("Location: vendedor.php");
    }
    catch (mysqli_sql_exception $exception)
    {
        mysqli_rollback($con);

        throw $exception;
        $_SESSION['msg'] = "<p style = 'color:red;'>  Vendedor não cadastrado </p>";
        header("Location: vendedor.php");
    }
    mysqli_close($con);
?> 