<?php

    session_start();
    include_once("conexao.php");
    $codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
    $result = "SELECT * FROM vendedor WHERE codigo = '$codigo'";
    $resultado = mysqli_query($con, $result);
    $row = mysqli_fetch_assoc($resultado);
    $id_vendedor = $row['codigo'];
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Editar</title>
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
    </head>
    <body>
        <h1>Alteração</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="editar_vendedor.php">
            <input type="hidden" name="codigo" value="<?php echo $row['codigo'];?>">
            <table>
                <tr>
                    <td>Nome: </td><td><input type="text" name="nome" value="<?php echo $row['nome'];?>"></td>
                </tr>
                <tr>
                    <td>Rua: </td><td><input type="text" name="rua" value="<?php echo $row['rua'];?>"></td><td>Nº:</td><td><input type="number" name="num" value="<?php echo $row['numero'];?>"></td>
                </tr>
                <tr>
                    <td>Bairro: </td><td><input type="text" name="bairro" value="<?php echo $row['bairro'];?>"></td>
                </tr>
                <tr>
                    <td>Cidade: </td><td ><input type="text" name="cidade" value="<?php echo $row['cidade'];?>"></td>
                </tr>
                <tr>
                    <td>Estado: </td><td><input type="text" name="estado" value="<?php echo $row['estado'];?>"></td>
                    <td>
                        <select name="estado">
                            <option value="SP">SP</option>
                            <option value="BA">BA</option>
                            <option value="RJ">RJ</option>
                            <option value="MG">MG</option>
                            <option value="PR">PR</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Telefone: </td><td><input type="tel" name="tel" placeholder="(xx) xxxxx-xxxx" value="<?php echo $row['telefone'];?>"></td>
                </tr>
                <tr>
                    <td>Comissão: </td><td><input type="number" name="comissao" value="<?php echo $row['porc_comissao'];?>"></td>
                </tr>
            </table>
            <p><button type="submit" value="cadastrar">Salvar</button>
        </form>
        <p><a href="home.html"><button>Voltar</button></a>
    </body>
</html>