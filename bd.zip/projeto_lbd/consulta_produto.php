<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <a href="home.html"><img src="lcm.jpg" width="100"></a>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa de Produtos</title>
    <hr>
    <style>
        body{
            width: 100vw;
            height: 100vh;
            /*display: flex;*/
            justify-content: center;
            align-items: center;
            background-color: #e7eed0;
        }
    </style>
</head>
<body>
    <h3>Filtrar por: </h3><br>
    <form action="" method="POST">
        <label>Nome do produto: </label><input type="text" name="nome" size="50"/>
        <label>Código: </label><input type="number" name="codigo"/>
        <label>Categoria: </label><input type="text" name="categoria" size="30"/>
        <p><input type="submit" name="SendPesqUser" value="Pesquisar">
    </form>
    <a href="salvar_produto.php"><button>Voltar</button></a>
    <hr size="15">

    <?php
    include("conexao.php");
    $SendPesqUser = filter_input(INPUT_POST, 'SendPesqUser', FILTER_SANITIZE_SPECIAL_CHARS);
    if($SendPesqUser)
    {
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $codigo = filter_input(INPUT_POST, 'codigo', FILTER_SANITIZE_SPECIAL_CHARS);
        $categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS);

        if(empty($nome) && empty($codigo) && empty($categoria))
        {
            $query = "SELECT*FROM consulta_produto";
        }
        elseif(empty($nome) && !empty($codigo) && empty($categoria))
        {
            $query = "SELECT*FROM consulta_produto WHERE codigo = '$codigo'";
        }
        elseif(!empty($nome) && !empty($codigo) && !empty($categoria))
        {
            $query = "SELECT*FROM consulta_produto WHERE nome LIKE '%$nome%' OR codigo = '$codigo'";
        }
        elseif(!empty($nome) && empty($codigo) && empty($categoria))
        {
            $query = "SELECT*FROM consulta_produto WHERE nome LIKE '%$nome%'";
        }
        else
        {
            $query = "SELECT*FROM consulta_produto WHERE descricao LIKE '%$categoria%'";
        }

        $resultado = mysqli_query($con, $query) or die("Erro ao retornar dados!");
        while($row = mysqli_fetch_assoc($resultado))
        {
            echo "Código: ".$row['codigo']."<br>";
            echo "Nome do produto: ".$row['nome']."<br>";
            echo "Preço: ".$row['preco']."<br>";
            echo "Estoque: ".$row['qtd_estoque']."<br>";
            echo "Unidade de medida: ".$row['unid_medida']."<br>";
            echo "Categoria: ".$row['descricao']."<br><br><hr>";
        }
    }
    ?>
</body>
</html>