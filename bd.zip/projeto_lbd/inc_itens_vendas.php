<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }

    //$id_produto = $_POST['id_produto'];
    $id_produtos = $_POST['id_produtos'];
    $id_vendas = $_POST['id_vendas'];
    $quantidade = $_POST['qtd'];

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    include('conexao.php');
    mysqli_begin_transaction($con) or die (mysqli_connect_error());
    try
    {
        $query = "INSERT INTO item_vendas (fk_cod_produto,fk_num_venda,quantidade) 
        VALUES ('$id_produtos', '$id_vendas', '$quantidade')";
        $resu = mysqli_query($con,$query);
    
        mysqli_commit($con);
        $_SESSION['msg'] = "<p style = 'color:green;'>  Venda cadastrada </p>";
        header("Location: itens_vendas.php");
    }
    catch (mysqli_sql_exception $exception)
    {
        mysqli_rollback($con);

        throw $exception;
        $_SESSION['msg'] = "<p style = 'color:red;'>  Venda não cadastrada </p>";
        header("Location: itens_vendas.php");
    }
    mysqli_close($con);
?> 