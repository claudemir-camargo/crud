<?php
session_start();
include_once('conexao.php');
$codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
$result = "SELECT * FROM produto WHERE codigo = '$codigo'";
$resultado = mysqli_query($con, $result);
$row = mysqli_fetch_assoc($resultado);
$fk_id_categoria = $row['fk_id_categoria'];
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>CRUD - Editar</title>
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
    </head>
    <body>
        <p><h1>Alteração - Produtos</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="proc_edit_produto.php">
            <input type="hidden" name="codigo" value="<?php echo $row['codigo'];?>">
            <label>Nome do produto:</label><input type="text" size="100" name="nome" value="<?php echo $row['nome'];?>">
            <p><label>Preço: <input type="number" min="0" step=".01" size="10" name="preco" value="<?php echo $row['preco'];?>">       
            <p><label>Quantidade em estoque: <input type="number" size="80" name="qtd_estoque" value="<?php echo $row['qtd_estoque'];?>">
            <p><label>Unidade de medida: <input type="text" name="unid_medida" value="<?php echo $row['unid_medida'];?>">
            <p><label>Categoria: </label>
            <select name="fk_id_categoria">
            <option value="Selecione" selected>Selecione</option>
            <?php
                include('conexao.php');
                $query = "SELECT * FROM categoria;";
                $resu = mysqli_query($con, $query) or die(mysqli_connect_error());
                $reg = mysqli_fetch_assoc($resu);
            ?> 
                  
            <?php
                $query2 = "SELECT * FROM categoria;";
                $resu2 = mysqli_query($con, $query2) or die(mysqli_connect_error());
                while($reg2 = mysqli_fetch_array($resu2)){
            ?>
                <option value="<?php echo $reg2['id'];?>"><?php echo $reg2['descricao'];?></option> 
                <?php
                    }
                    mysqli_close($con);
                ?>
            </select>
            <p><button type="submit" value="cadastrar">Salvar</button>
        </form>
    </body>
</html>