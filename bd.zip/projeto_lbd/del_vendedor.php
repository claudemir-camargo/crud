<?php

    session_start();
    include_once("conexao.php");
    $codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
    $result = "SELECT * FROM vendedor WHERE codigo = '$codigo'";
    $resultado = mysqli_query($con, $result);
    $row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
    </head>
    <body>
        <h1>Excluir</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="deletar_vendedor.php">
            <input type="hidden" name="codigo" value="<?php echo $row['codigo'];?>">
            <table>
                <tr>
                    <td>Nome: </td><td><input type="text" name="nome" value="<?php echo $row['nome'];?>" disabled></td>
                </tr>
            </table>
            <button type="submit" value="excluir">Excluir</button>
        </form>
        <p><a href="busca_v.php"><button>Voltar</button></a>
        <?php mysqli_close($con) ?>
    </body>
</html>