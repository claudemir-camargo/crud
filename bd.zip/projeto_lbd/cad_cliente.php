<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <meta charset="UTF-8">
        <title>Cadastro de cliente</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body> 
        <?php
                if(isset($_SESSION['msg']))
                {
                    echo $_SESSION['msg'];
                    unset($_SESSION['msg']);
                }
        ?>
        
        <div>
        <p><h1>Cadastro de cliente</h1></p>
        <hr>
        <form method="POST" action="inc_cliente.php">
        <label><p>Nome completo: </label><input type="text" size="50" name="nome">
        <label><p>CPF: <input type="text" size="20" name="cpf"></p></label>
        <label><p>Email: <input type="email" size="50" name="email" maxlength="100" placeholder="seuemail@teste.com.br" ></p></label>
        <label><p>Rua: <input type="text" size="50" name="rua" maxlength="100"></p></label>
        <label><p>Número: <input type="number" size="3" name="numero"></p></label>
        <label><p>Bairro: <input type="text" size="50" name="bairro"></p></label>
        <label>Cidade: <input type="text" size="50" name="cidade">
        <select name="estado">
			<option value="vazio" selected>Estado</option>
			<option value="SP" >São Paulo</option>
			<option value="MG">Minas Gerais</option>
			<option value="RJ" >Rio de Janeiro</option>
			<option value="ES">Espírito Santo</option>
		</select></label>
        <label><p>Telefone: <input type="text" size="20" name="telefone" maxlength="100" placeholder="(00) 00000-0000"></p></label>
        <label><p>Limite de crédito: <input type="number" min="0" step=".01" size="20" name="limite_cred" maxlength="100"></p></label>
        <p><button type="submit" value="cadastrar">Cadastrar</button>
        <button type="reset" value="Limpar">Limpar</button> 
        </form>
        <div>
            <p><a href="home.html"><button>Voltar</button></a>
            <a href="alter_cliente.php"><button>Tabela de Clientes</button></a>
            <a href="consulta_cliente.php"><button>Consulta de Clientes</button></a>
        </div>
        </div>
        
        
    </body>
</html>