<?php
session_start();
include('conexao.php');

$id = $_POST['id'];
$descricao = $_POST['descricao'];
$result = "UPDATE categoria SET descricao='$descricao' WHERE id='$id'";
$resultado = mysqli_query($con, $result);

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Categoria alterada com sucesso</p>";
    header("Location: alter_categoria.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Categoria não foi alterada</p>";
    header("Location: alter_categoria.php?id=$id");
}
?>