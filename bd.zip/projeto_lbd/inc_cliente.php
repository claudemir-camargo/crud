<?php
if (session_status() !== PHP_SESSION_ACTIVE)
{
    session_start();
}
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$telefone = $_POST['telefone'];
$limite_cred = $_POST['limite_cred'];

include('conexao.php');

$query = "INSERT INTO cliente(nome, cpf, email, rua, numero, bairro, cidade, estado, telefone, limite_cred)
 VALUES ('$nome', '$cpf', '$email', '$rua', '$numero', '$bairro', '$cidade', '$estado', '$telefone', '$limite_cred')";
$resu = mysqli_query($con, $query);

if (mysqli_insert_id($con))
{
    $_SESSION['msg'] = "<p style = 'color:blue;'> Cliente cadastrado com sucesso!</p>";
    header('Location: cad_cliente.php');
}
else
{
    $_SESSION['msg'] = "<p style = 'color:red;'> Cliente não cadastrado!</p>";
    header('Location: cad_cliente.php');
}
mysqli_close($con);
?>