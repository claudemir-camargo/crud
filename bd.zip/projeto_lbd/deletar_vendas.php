<?php 
    session_start();
    $codigo = $_POST['numero'];

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    include("conexao.php");
    mysqli_begin_transaction($con) or die (mysqli_connect_error());
    try
    {
        $query_vendedor = "DELETE FROM venda WHERE numero = '$codigo'";
        $result = mysqli_query($con, $query_vendedor);

        // Falta colocar o delete para apagar o vendedor da tabela vendas.
        
        mysqli_commit($con);
        $_SESSION['msg'] = "<p style = 'color:green;'> Exclusão concluida </p>";
        header("Location: tabela_vendas.php");
    }
    catch (mysqli_sql_exception $exception)
    {
        mysqli_rollback($con);
        throw $exception;
        $_SESSION['msg'] = "<p style = 'color:green;'> Falha na exclusão </p>";
        header("Location: tabela_vendas.php");
    }
    mysqli_close($con);
?>