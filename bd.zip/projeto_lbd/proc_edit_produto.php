<?php
session_start();
include('conexao.php');

$codigo = $_POST['codigo'];
$nome = $_POST['nome'];
$preco = $_POST['preco'];
$qtd_estoque = $_POST['qtd_estoque'];
$unid_medida = $_POST['unid_medida'];
$fk_id_categoria = $_POST['fk_id_categoria'];
$result = "UPDATE produto SET nome='$nome', preco='$preco', qtd_estoque='$qtd_estoque', 
unid_medida='$unid_medida', fk_id_categoria='$fk_id_categoria' WHERE codigo='$codigo'";
$resultado = mysqli_query($con, $result) or die(mysqli_connect_error());

if(mysqli_affected_rows($con)){
    $_SESSION['msg'] = "<p style='color:green;'>Produto alterado com sucesso</p>";
    header("Location: alter_produto.php");
}
else{
    $_SESSION['msg'] = "<p style='color:red;'>Produto não foi alterado, verifique novamente</p>";
    header("Location: alter_produto.php");
}
mysqli_close($con);
?>