<?php
session_start();
include_once('conexao.php');
$codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
$result = "SELECT * FROM cliente WHERE codigo = '$codigo'";
$resultado = mysqli_query($con, $result);
$row = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>CRUD - Editar</title>
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
    </head>
    <body>
        <p><h1>Alteração - Clientes</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="proc_edit_cliente.php">
            <input type="hidden" name="codigo" value="<?php echo $row['codigo'];?>">
            <label><p>Nome completo: <input type="text" size="80" name="nome" maxlength="100" value="<?php echo $row['nome'];?>">
            <label><p>CPF: <input type="text" size="80" name="cpf" maxlength="100" value="<?php echo $row['cpf'];?>"></p>
            <label><p>Email: <input type="email" size="80" name="email" maxlength="100" value="<?php echo $row['email'];?>">
            <label><p>Rua: <input type="text" size="80" name="rua" maxlength="100" value="<?php echo $row['rua'];?>">
            <label><p>Número: <input type="number" size="80" name="numero" maxlength="100" value="<?php echo $row['numero'];?>">
            <label><p>Bairro: <input type="text" size="80" name="bairro" maxlength="100" value="<?php echo $row['bairro'];?>">
            <label><p>Cidade: <input type="text" size="50" name="cidade" maxlength="100" value="<?php echo $row['cidade'];?>">
            Estado: <select name="estado">
			            <option value="<?php echo $row['estado'];?>"> <?php echo $row['estado'];?></option>
			            <option value="SP">São Paulo</option>
			            <option value="MG">Minas Gerais</option>
			            <option value="RJ" >Rio de Janeiro</option>
			            <option value="ES">Espírito Santo</option>
		                </select>
            <label><p>Telefone: <input type="text" size="20" name="telefone" maxlength="20" value="<?php echo $row['telefone'];?>">
            <label><p>Limite de crédito: <input type="number" min="0" step=".01" size="20" name="limite_cred" value="<?php echo $row['limite_cred'];?>">
            <p><button type="submit" value="cadastrar">Salvar</button>
        </form>
        <a href="alter_cliente.php"><button>Voltar</button></a>
    </body>
</html>