<?php include'conexao.php'?>

<!DOCTYPE html>
<html>
    <head>
        <title>Tabela Vendas</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <hr>
    </head>
    <body>
        <form method="POST">
            <input type="date" name="data_inicial">
            <input type="date" name="data_final"><br>
            <input type="submit" name="search" value="Pesquisar">
            <hr size="15">
            <table border="1" width="95%" style="background-color: aqua; text-align: center; font-size: 15px;
		    font-family: arial, sans-serif;">
            <thead style="background-color: blue;">
            <tr>
                <th>Número</th>
                <th>Cliente</th>
                <th>Código Cliente</th>
                <th>Vendedor</th>
                <th>Código Vendedor</th>
                <th>Data</th>
                <th>Prazo de Entrega</th>
                <th>Condição Pagamento</th>
                <th>Excluir</th>
            </tr>
        </thead>
                    <?php 
                        if(!empty($_POST['search']))
                        {
                            $txtStartDate = $_POST['data_inicial'];
                            $txtEndDate = $_POST['data_final'];
                            $query ="SELECT v.numero,c.nome AS cliente,ve.nome AS vendedor,v.data AS data,v.prazo_entrega,v.cond_pagamento,v.fk_cod_cliente,v.fk_cod_vendedor FROM venda v
                            INNER JOIN cliente c ON v.fk_cod_cliente = c.codigo
                            INNER JOIN vendedor ve ON v.fk_cod_vendedor = ve.codigo
                            WHERE v.data BETWEEN '$txtStartDate' AND '$txtEndDate' ORDER BY v.data";

                            $resul_busca = mysqli_query($con, $query) or die (mysqli_connect_error());
                            while($linha_c = mysqli_fetch_array($resul_busca))
                            {
                                echo "<tr><td>" .$linha_c['numero'] . "</td>";
                                echo "<td>" .$linha_c['cliente'] . "</td>";
                                echo "<td>" . $linha_c['fk_cod_cliente'] . "</td>";
                                echo "<td>" .$linha_c['vendedor'] . "</td>";
                                echo "<td>" . $linha_c['fk_cod_vendedor'] . "</td>";
                                echo "<td>" . $linha_c['data'] . "</td>";
                                echo "<td>" .$linha_c['prazo_entrega'] . "</td>";
                                echo "<td>" . $linha_c['cond_pagamento'] . "</td>";
                                echo "<td><a href='del_vendas.php?numero=".$linha_c['numero']."'><img src='deletar.png'/></a></td></tr>";
                            }
                        }
                    ?>
            </table>
        </form>
        <div>
        <p><a href="relatorio_vendas.php" target="_blank"><button>Relatório</button></a><br>
        <p><a href="vendas.php"><button>Voltar</button></a><br>
        </div>
        
    </body>
</html>