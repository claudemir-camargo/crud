<?php

    session_start();
    include_once("conexao.php");
    $codigo = filter_input(INPUT_GET, 'numero', FILTER_SANITIZE_NUMBER_INT);
    $result = "SELECT * FROM venda WHERE numero = '$codigo'";
    $resultado = mysqli_query($con, $result);
    $row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <title>Excluir Venda</title>
    </head>
    <body>
        <h1>Excluir</h1>
        <?php
            if(isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <form method="POST" action="deletar_vendas.php">
            <input type="hidden" name="numero" value="<?php echo $row['numero'];?>">
            <table>
                <tr>
                    <td>id_vendas: </td><td><input type="number" name="id_cliente" value="<?php echo $row['numero'];?>"></td>
                    <td>id_cliente: </td><td><input type="number" name="id_cliente" value="<?php echo $row['fk_cod_cliente'];?>"></td>
                    <td>id_vendedor: </td><td><input type="number" name="id_vendedor" value="<?php echo $row['fk_cod_vendedor'];?>"></td>
                </tr>
                <tr>
                    <td>data: </td><td><input type="date" name="data" value="<?php echo $row['data'];?>"></td>
                </tr>
                <tr>
                    <td>Prazo/Entrega: </td><td><input type="text" name="entrega" value="<?php echo $row['prazo_entrega'];?>"></td>
                </tr>
                <tr>
                    <td>Cond_pagto: </td><td><input type="text" name="cond_pagto" value="<?php echo $row['cond_pagamento'];?>"></td>
                </tr>
                
            </table>
            <button type="submit" value="excluir">Excluir</button>
            
        </form>
        <p><a href="tabela_vendas.php"><button>Voltar</button></a> 
        
        <?php mysqli_close($con) ?>
    </body>
</html>