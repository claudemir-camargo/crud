<?php
session_start();
include_once('conexao.php');
$codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_NUMBER_INT);
$result = "SELECT * FROM cliente WHERE codigo = '$codigo'";
$resultado = mysqli_query($con, $result);
$row = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <a href="home.html"><img src="lcm.jpg" width="100"></a>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - Excluir</title>
    <hr>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Exclusão - Cliente</h1>
    <?php
    if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
        }
    ?>
    <form method="POST" action="proc_del_cliente.php">
        <input type="hidden" name="codigo" value="<?php echo $row['codigo']; ?>">
        <label>Cliente: </label>
        <p><input type="text" name="nome" value="<?php echo $row['nome']; ?>" disabled><br><br>
        <button type="submit" value="excluir">Excluir</button>
    </form>   
    <p><a href="alter_cliente.php"><button>Voltar</button></a>
</body>
</html>