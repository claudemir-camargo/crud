<?php
    if (session_status() !== PHP_SESSION_ACTIVE)
    {
        session_start();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Itens Venda</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css">
        <a href="home.html"><img src="lcm.jpg" width="100"></a>
        <hr>
    </head>
    <body>
        <?php
            if (isset($_SESSION['msg']))
            {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
        ?>
        <div class="box">
            <form method="POST" action="inc_itens_vendas.php">
                <div class="form">
                    <h2>Itens Vendas</h2>
                    <div class="inputbox">
                        <table>
                            <tr>
                                <td>Código Produto: </td><td><input type="number" name="id_produtos" ></td>
                                
                                 <td>Código Venda: </td><td><input type="number" name="id_vendas" ></td>
                            </tr>
                            <tr>
                                <td>Quantidade Vendida: </td><td><input type="number" name="qtd" ></td>
                            </tr>
                        </table>
                    </div>
                    <p><button type="submit" value="cadastrar">Cadastrar</button>
                    <button type="reset" value="Limpar">Limpar</button>     
                </div>
            </form>
            <div>
                <a href="tabela_vendas_produtos.php"><button>Tabelas Vendas/Produtos</button></a>
                <a href="tabela_itens_vendas.php"><button>Tabelas Itens/Vendas</button></a>
                <p><a href="home.html"><button>Voltar</button></a><br>
            </div>
        </div>
    </body>
</html>